import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Ders> dersListesi = new ArrayList<>();
        ArrayList<Ogrenci> ogrenciListesi = new ArrayList<>();

        // Proje Menü Formu
        JFrame menuFrame = new JFrame("Proje Menü Formu");
        JButton dersKayitButton = new JButton("Ders Kayıt Formu");
        JButton ogrenciKayitButton = new JButton("Öğrenci Kayıt Formu");

        DersKayitFormu dersFormu = new DersKayitFormu(dersListesi);
        OgrenciKayitFormu ogrenciFormu = new OgrenciKayitFormu(dersListesi, ogrenciListesi);

        dersKayitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dersFormu.goster();
            }
        });

        ogrenciKayitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ogrenciFormu.goster();
            }
        });

        menuFrame.setLayout(new FlowLayout());
        menuFrame.add(new JLabel("Proje Menü Formu"));
        menuFrame.add(new JLabel("----------------------------"));
        menuFrame.add(dersKayitButton);
        menuFrame.add(ogrenciKayitButton);

        menuFrame.setSize(300, 150);
        menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuFrame.setVisible(true);
    }
}
