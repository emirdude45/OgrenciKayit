import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class DersKayitFormu {
    private ArrayList<Ders> dersListesi;

    public DersKayitFormu(ArrayList<Ders> dersListesi) {
        this.dersListesi = dersListesi;
    }

    public void goster() {
        JFrame dersFrame = new JFrame("Ders Kayıt Formu");
        JTextField dersKoduField = new JTextField(10);
        JTextField dersAdField = new JTextField(10);
        JTextField dersDonemField = new JTextField(10);
        JButton kaydetButton = new JButton("Kaydet");

        kaydetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dersKodu = dersKoduField.getText();
                String dersAd = dersAdField.getText();
                String dersDonem = dersDonemField.getText();

                Ders yeniDers = new Ders(dersKodu, dersAd, dersDonem);
                dersListesi.add(yeniDers);

                JOptionPane.showMessageDialog(dersFrame, "Ders kaydedildi!");
            }
        });

        dersFrame.setLayout(new FlowLayout());
        dersFrame.add(new JLabel("Ders Kayıt Formu"));
        dersFrame.add(new JLabel("-----------------------------"));
        dersFrame.add(new JLabel("Ders Kodu:"));
        dersFrame.add(dersKoduField);
        dersFrame.add(new JLabel("Ders Adı:"));
        dersFrame.add(dersAdField);
        dersFrame.add(new JLabel("Ders Dönemi:"));
        dersFrame.add(dersDonemField);
        dersFrame.add(kaydetButton);

        dersFrame.setSize(300, 150);
        dersFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dersFrame.setVisible(true);
    }
}
