import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class OgrenciKayitFormu {
    private ArrayList<Ders> dersListesi;
    private ArrayList<Ogrenci> ogrenciListesi;

    public OgrenciKayitFormu(ArrayList<Ders> dersListesi, ArrayList<Ogrenci> ogrenciListesi) {
        this.dersListesi = dersListesi;
        this.ogrenciListesi = ogrenciListesi;
    }

    public void goster() {
        JFrame ogrenciFrame = new JFrame("Öğrenci Kayıt Formu");
        JTextField ogrenciNoField = new JTextField(10);
        JTextField ogrenciAdField = new JTextField(10);
        JTextField ogrenciSoyadField = new JTextField(10);
        JTextField ogrenciBolumField = new JTextField(10);
        JComboBox<String> derslerComboBox = new JComboBox<>();

        for (Ders ders : dersListesi) {
            derslerComboBox.addItem(ders.dersAd);
        }

        JButton kaydetButton = new JButton("Kaydet");

        kaydetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int ogrenciNo = Integer.parseInt(ogrenciNoField.getText());
                String ogrenciAd = ogrenciAdField.getText();
                String ogrenciSoyad = ogrenciSoyadField.getText();
                String ogrenciBolum = ogrenciBolumField.getText();
                ArrayList<Ders> seciliDersler = new ArrayList<>();

                for (Object selectedDers : derslerComboBox.getSelectedObjects()) {
                    for (Ders ders : dersListesi) {
                        if (ders.dersAd.equals(selectedDers)) {
                            seciliDersler.add(ders);
                        }
                    }
                }

                Ogrenci yeniOgrenci = new Ogrenci(ogrenciNo, ogrenciAd, ogrenciSoyad, ogrenciBolum, seciliDersler);
                ogrenciListesi.add(yeniOgrenci);

                JOptionPane.showMessageDialog(ogrenciFrame, "Öğrenci kaydedildi!");
            }
        });

        ogrenciFrame.setLayout(new FlowLayout());
        ogrenciFrame.add(new JLabel("Öğrenci Kayıt Formu"));
        ogrenciFrame.add(new JLabel("-----------------------------"));
        ogrenciFrame.add(new JLabel("Öğrenci No:"));
        ogrenciFrame.add(ogrenciNoField);
        ogrenciFrame.add(new JLabel("Ad:"));
        ogrenciFrame.add(ogrenciAdField);
        ogrenciFrame.add(new JLabel("Soyad:"));
        ogrenciFrame.add(ogrenciSoyadField);
        ogrenciFrame.add(new JLabel("Bölüm:"));
        ogrenciFrame.add(ogrenciBolumField);
        ogrenciFrame.add(new JLabel("Dersler:"));
        ogrenciFrame.add(derslerComboBox);
        ogrenciFrame.add(kaydetButton);

        ogrenciFrame.setSize(300, 200);
        ogrenciFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ogrenciFrame.setVisible(true);
    }
}
