import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class OgrenciDersKayitUygulamasi {
    private static ArrayList<Ders> dersListesi = new ArrayList<>();
    private static ArrayList<Ogrenci> ogrenciListesi = new ArrayList<>();

    public static void main(String[] args) {
        // Proje Menü Formu
        JFrame menuFrame = new JFrame("Proje Menü Formu");
        JButton dersKayitButton = new JButton("Ders Kayıt Formu");
        JButton ogrenciKayitButton = new JButton("Öğrenci Kayıt Formu");

        DersKayitFormu dersFormu = new DersKayitFormu(dersListesi);
        OgrenciKayitFormu ogrenciFormu = new OgrenciKayitFormu(dersListesi, ogrenciListesi); // OgrenciListesi eklendi

        dersKayitButton.addActionListener(e -> dersFormu.goster());
        ogrenciKayitButton.addActionListener(e -> ogrenciFormu.goster());

        menuFrame.setLayout(new FlowLayout());
        menuFrame.add(new JLabel("Proje Menü Formu"));
        menuFrame.add(new JLabel("----------------------------"));
        menuFrame.add(dersKayitButton);
        menuFrame.add(ogrenciKayitButton);

        menuFrame.setSize(300, 150);
        menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuFrame.setVisible(true);
    }
}
