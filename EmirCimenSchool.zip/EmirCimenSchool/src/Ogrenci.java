import java.util.ArrayList;

public class Ogrenci {
    int ogrenciNo;
    String ogrenciAd;
    String ogrenciSoyad;
    String ogrenciBolum;
    ArrayList<Ders> ogrenciDersler;

    public Ogrenci(int ogrenciNo, String ogrenciAd, String ogrenciSoyad, String ogrenciBolum, ArrayList<Ders> ogrenciDersler) {
        this.ogrenciNo = ogrenciNo;
        this.ogrenciAd = ogrenciAd;
        this.ogrenciSoyad = ogrenciSoyad;
        this.ogrenciBolum = ogrenciBolum;
        this.ogrenciDersler = ogrenciDersler;
    }
}
